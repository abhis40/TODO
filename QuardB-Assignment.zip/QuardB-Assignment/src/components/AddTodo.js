
import React, { useState } from 'react';
import { useDispatch } from 'react-redux';
import { addTodo } from '../redux/actions/todoActions';

const AddTodo = () => {
  const [task, setTask] = useState('');
  const dispatch = useDispatch();

  const handleSubmit = (e) => {
    e.preventDefault();
    if (task.trim()) {
      dispatch(addTodo({
        id: Date.now(),
        task,
        completed: false,
      }));
      setTask('');
    }
  };

  return (
    <form onSubmit={handleSubmit} className="mb-4">
      <input 
        type="text" 
        value={task} 
        onChange={(e) => setTask(e.target.value)}
        className="p-2 border rounded w-full bg-gray-700 text-white focus:outline-none focus:ring-2 focus:ring-green-500"
        placeholder="Add a new task"
      />
      <button type="submit" className="mt-4 p-2 bg-green-400 hover:bg-green-600 text-white rounded-2xl  w-full transition">
        Add Todo
      </button>
    </form>
  );
};

export default AddTodo;
