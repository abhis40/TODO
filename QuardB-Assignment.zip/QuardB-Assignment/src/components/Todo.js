
import React, { useState } from 'react';
import { useDispatch } from 'react-redux';
import { deleteTodo, editTodo } from '../redux/actions/todoActions';

const Todo = ({ todo }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [task, setTask] = useState(todo.task);
  const dispatch = useDispatch();

  const handleDelete = () => {
    dispatch(deleteTodo(todo.id));
  };

  const handleEdit = () => {
    dispatch(editTodo({
      ...todo,
      task,
    }));
    setIsEditing(false);
  };

  return (
    <div className="flex items-center justify-between p-2 bg-gray-700 rounded-lg mb-2 shadow">
      {isEditing ? (
        <input
          type="text"
          value={task}
          onChange={(e) => setTask(e.target.value)}
          className="p-2 border rounded w-full mr-2 bg-gray-600 text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
        />
      ) : (
        <span className="text-white">{todo.task}</span>
      )}
      <div className="flex space-x-2">
        {isEditing ? (
          <button onClick={handleEdit} className="p-2 bg-green-500 hover:bg-green-600 text-white rounded transition">
            Save
          </button>
        ) : (
          <button onClick={() => setIsEditing(true)} className="p-2 bg-yellow-500 hover:bg-yellow-600 text-white rounded transition">
            Edit
          </button>
        )}
        <button onClick={handleDelete} className="p-2 bg-red-500 hover:bg-red-600 text-white rounded transition">
          Delete
        </button>
      </div>
    </div>
  );
};

export default Todo;
